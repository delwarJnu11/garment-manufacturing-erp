<div class="form-login" style="width: 200px">
    <button type="submit" class="btn btn-login">{{$slot}}</button>
</div>