<div>
    <div class="row">
        @if (session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    </div>
</div>
