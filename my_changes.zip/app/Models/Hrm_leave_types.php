<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Hrm_leave_types extends Model
{
    //
}
