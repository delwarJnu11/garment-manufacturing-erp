<?php

return [
   'customer'=> 19,
   'supplier'=>18, 
];