<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class asset_status extends Model
{
    //
}
