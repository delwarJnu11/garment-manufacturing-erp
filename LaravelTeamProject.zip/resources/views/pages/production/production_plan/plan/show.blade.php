plan show
