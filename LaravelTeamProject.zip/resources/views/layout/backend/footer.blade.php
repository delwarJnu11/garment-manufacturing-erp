<footer style="background: #e5e5e5; color: #414141;" class="p-2 text-center">
    <p>&#169; All Rights Reserved by WDPF61</p>
</footer>
