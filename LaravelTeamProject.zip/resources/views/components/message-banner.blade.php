@if ($msg)
    <div class="alert {{ $class }} bg-lime-700">
        {{ $msg }}
    </div>
@endif
